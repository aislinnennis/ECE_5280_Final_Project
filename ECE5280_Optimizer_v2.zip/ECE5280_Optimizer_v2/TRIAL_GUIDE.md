# Experiments for the next run

1. **First:** run notebook without changing defaults. Confirm the matplotlib warning disappears.
2. **Second:** inspect printed hourly interval coverage (the ±$2.5/MWh box may be too narrow).
3. **Third:** compare continuation values 0, 20, 40, 60, 80 $/MWh and see how much stored energy remains each day.
4. **Fourth:** optionally increase days from 14 to 60 (e.g. TRAIN_START=250, DAYS=60). Compare which settings remain effective; avoid claiming guaranteed improvement from a single training slice.
5. **Fifth:** save the notebook, rerun its final export cell, upload `ECE5280_RESULTS_TO_SHARE.zip`. It contains code, tests, figures, per-day CSVs, summary CSVs, and runtime metadata.

**Theory:** SOC feasible set is convex for all prices (Al Taha–Bitar Thm. 2); objective is convex only under the slope condition. The naive split-charge LP is a relaxation and can be physically invalid. The hybrid returns feasible schedules and uses MILP when needed.
