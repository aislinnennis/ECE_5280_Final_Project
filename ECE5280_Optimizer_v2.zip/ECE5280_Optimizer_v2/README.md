# ECE 5280 — Battery optimizer v2: follow-up to your first results ZIP

**Start here:** run `python -m pip install -r requirements.txt` from this extracted folder, then open `ECE5280_Optimizer_v2.ipynb` in Jupyter Notebook or JupyterLab. Select **Kernel → Restart & Run All**.

This update was based on the user-generated `ECE5280_RESULTS_TO_SHARE.zip` (14-day run, starting at training day 300) and the macOS `FigureCanvasAgg` warning. The new notebook explains the mathematics alongside editable trial settings, automated checks, schedule and SOC plots, and a results ZIP exporter.

## Fix to the plotting warning

The former `experiments.py` used `matplotlib.use('Agg')`, which made `plt.show()` warn about a noninteractive canvas. This line has been removed. The notebook now runs `%matplotlib inline` *before* importing modules that import `matplotlib.pyplot`, so notebook figures should display inline. A standalone script run on a display-less server can set `MPLBACKEND=Agg` externally; figures are saved as files in either mode. If you have imported the old version into the kernel already, restart the kernel before running all cells.

## What the solvers actually do

- `optimize_lossless`: exact LP with affine battery dynamics.
- `optimize_lossy_soc_convex`: exact convex SOC-coordinate LP **when** the branch slope inequality holds for every hour. Based on Al Taha & Bitar (arXiv:2403.14010v2). The SOC feasible set is always convex; the objective is not always convex.
- `optimize_lossy_milp`: exact mixed-integer reference/fallback for other prices.
- `optimize_lossy_hybrid`: uses exact SOC LP when possible, MILP otherwise, with physical feasibility checks.
- `optimize_lossy_relaxation`: split-power **outer LP relaxation for diagnostics only** (not safe to submit unchecked).

All procedures enforce 5 MWh storage capacity, ±2.5 MWh per one-hour exchange, and lossy ηin=ηout=0.95. The 2.5 physical power limit is **not** an uncertainty bound. The arbitrary robust price radius is independently configured in $/MWh.

## New experiments after the first results ZIP

1. **Continuation value for daily stored energy:** `run_terminal_value_sweep` tests $0, $20, $40, $60, $80 per MWh as an estimated value for energy carried to tomorrow. On the run's **last day the value is always zero**, honoring the no-final-credit rule. Scores use actual historical revenue, not added virtual salvage value. Results: `results/terminal_value_summary.csv`, `results/terminal_value_daily.csv`, and two PNGs. It is a *heuristic* and NOT a learned future-value function.
2. **Uncertainty coverage audit:** Backtest CSV and summary now record the fraction of actual hourly prices within forecast ±ρ. A box-robust objective only gives a worst-case guarantee **conditional on actual prices lying in the specified box**.
3. **More unit tests:** LP/MILP equivalence with terminal continuation value, final-day terminal credit disabled, worst-case box inequality check.
4. **Plotting:** Avoids forcing a noninteractive backend in the notebook.

## Practical workflow

1. Edit the trial settings near the start of the notebook: `DAYS`, `TRAIN_START`, `PRICE_RADII`. The defaults reproduce your 14-day prior trial. For a longer comparison, set `DAYS=60`, `TRAIN_START=250` (fits within the released 366-day period).
2. Run every cell and look for `Ran 13 tests ... OK` and inspect the inline charts. Then compare the original backtest summary to the `terminal_value_*` files.
3. Optionally tune `TERMINAL_VALUES` and `TERMINAL_RADII`, but avoid choosing settings based only on a single short period. Always track both prediction and **realized** revenue.
4. **Save the notebook**, then run its last ZIP export cell again. Upload the new `ECE5280_RESULTS_TO_SHARE.zip` for another iteration.

Without Jupyter, run `python -m unittest -v test_optimizer.py`, then `python experiments.py --days 14 --start 300`, then use the notebook for continuation sweeps or call `run_terminal_value_sweep()` from Python.

## Important project boundary

These are offline tests on the released CSVs; they are **not** GradeScope validation or test results. The two historical-price forecasters are temporary baselines. Vaishnavi's model needs to return 24 hourly predictions and Kevin's backtester needs to carry stored energy between days. The exact nine-argument `schedule_lossless` and `schedule_lossy` submission wrappers are **not yet implemented**.

Academic integrity: disclose AI assistance in the submitted README, validate every calculation, and write the final report text yourselves (as the assignment requires).

References: ECE 4800/5280 Fall 2026 Final Project; F. Al Taha and E. Bitar, *When Are Lossy Energy Storage Optimization Models Convex?*, arXiv:2403.14010v2.
