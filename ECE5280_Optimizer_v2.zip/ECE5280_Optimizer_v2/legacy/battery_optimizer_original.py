"""ECE 4800/5280 battery scheduling: deterministic optimization subproblem.

These functions optimize against an input vector of *predicted* prices, not
realized prices. No current-day realized observations are used.

Positive grid exchange p[t] means charging; negative means discharging.
Output is a 24-element ndarray of grid exchanges in MWh.
"""
from __future__ import annotations

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, linprog, milp
from scipy.sparse import lil_matrix

T = 24
CAPACITY = 5.0
POWER = 2.5
EFF_IN = 0.95
EFF_OUT = 0.95


def _validate_inputs(predicted_prices, initial_energy):
    prices = np.asarray(predicted_prices, dtype=float).reshape(-1)
    if prices.shape != (T,) or not np.all(np.isfinite(prices)):
        raise ValueError("predicted_prices must contain exactly 24 finite values")
    energy = float(initial_energy)
    if not np.isfinite(energy) or not (0 <= energy <= CAPACITY):
        raise ValueError("initial_energy must be finite and within [0, 5]")
    return prices, energy


def optimize_lossless(predicted_prices, initial_energy):
    """Solve the lossless 24-hour LP exactly, subject to solver tolerance."""
    prices, energy = _validate_inputs(predicted_prices, initial_energy)
    # Revenue is -prices @ p, so minimize prices @ p.
    # Stored energy after hour k is energy + sum_{t<=k} p[t].
    triangular = np.tril(np.ones((T, T)))
    A_ub = np.vstack((triangular, -triangular))
    b_ub = np.concatenate((np.full(T, CAPACITY - energy), np.full(T, energy)))
    result = linprog(prices, A_ub=A_ub, b_ub=b_ub,
                     bounds=[(-POWER, POWER)] * T, method="highs")
    if not result.success:
        raise RuntimeError(f"Lossless LP failed: {result.message}")
    schedule = np.asarray(result.x)
    check_schedule(schedule, energy, lossy=False)
    return schedule


def optimize_lossy(predicted_prices, initial_energy):
    """Solve exact no-simultaneous-charge/discharge MILP for 95%/95% battery.

    Decision variables: c[24] >= 0 (grid charging), d[24] >= 0
    (grid discharging), y[24] in {0,1} (charge/discharge mode).
    p = c-d, s_next = s + 0.95*c - d/0.95.
    Binary y disallows c and d being positive in the same hour.
    """
    prices, energy = _validate_inputs(predicted_prices, initial_energy)
    n = 3 * T
    objective = np.concatenate((prices, -prices, np.zeros(T)))
    lower = np.zeros(n)
    upper = np.concatenate((np.full(2 * T, POWER), np.ones(T)))

    # c_t <= POWER*y_t; d_t <= POWER*(1-y_t).
    # Cumulative state constraints at every hour end.
    A = lil_matrix((4 * T, n), dtype=float)
    lb = np.full(4 * T, -np.inf)
    ub = np.zeros(4 * T)
    for t in range(T):
        A[t, t] = 1
        A[t, 2 * T + t] = -POWER
        A[T + t, T + t] = 1
        A[T + t, 2 * T + t] = POWER
        ub[T + t] = POWER
        A[2 * T + t, :t + 1] = EFF_IN
        A[2 * T + t, T:T + t + 1] = -1 / EFF_OUT
        ub[2 * T + t] = CAPACITY - energy
        A[3 * T + t, :t + 1] = EFF_IN
        A[3 * T + t, T:T + t + 1] = -1 / EFF_OUT
        lb[3 * T + t] = -energy
        ub[3 * T + t] = np.inf

    integrality = np.zeros(n, dtype=int)
    integrality[2 * T:] = 1
    result = milp(objective, integrality=integrality,
                  bounds=Bounds(lower, upper),
                  constraints=LinearConstraint(A.tocsr(), lb, ub),
                  options={"time_limit": 20.0, "mip_rel_gap": 1e-8})
    # A timed-out feasible solution might still be safe; for starter purposes
    # require optimality (status 0) and fail clearly otherwise.
    if result.status != 0 or result.x is None:
        raise RuntimeError(f"Lossy MILP did not solve to optimality: {result.message}")
    schedule = result.x[:T] - result.x[T:2 * T]
    check_schedule(schedule, energy, lossy=True)
    return schedule


def stored_energy(schedule, initial_energy, *, lossy=False):
    """State vector with 25 entries, including initial and end energy."""
    p = np.asarray(schedule, dtype=float).reshape(-1)
    if p.shape != (T,):
        raise ValueError("schedule must have exactly 24 entries")
    if lossy:
        increments = EFF_IN * np.maximum(p, 0) + np.minimum(p, 0) / EFF_OUT
    else:
        increments = p
    return np.r_[float(initial_energy), float(initial_energy) + np.cumsum(increments)]


def check_schedule(schedule, initial_energy, *, lossy=False, tol=1e-6):
    """Raise an informative error on infeasible or nonfinite schedules."""
    p = np.asarray(schedule, dtype=float).reshape(-1)
    if p.shape != (T,) or not np.isfinite(p).all():
        raise ValueError("schedule must contain 24 finite values")
    if np.any(p < -POWER - tol) or np.any(p > POWER + tol):
        raise ValueError("power limits violated")
    states = stored_energy(p, initial_energy, lossy=lossy)
    if np.any(states < -tol) or np.any(states > CAPACITY + tol):
        raise ValueError("energy capacity limits violated")
    return True


def revenue(actual_prices, schedule):
    """Use only for offline evaluation once realized prices are known."""
    prices = np.asarray(actual_prices, dtype=float).reshape(-1)
    p = np.asarray(schedule, dtype=float).reshape(-1)
    if prices.shape != (T,) or p.shape != (T,):
        raise ValueError("prices and schedule must each contain 24 entries")
    return float(-prices @ p)
