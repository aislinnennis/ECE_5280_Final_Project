"""Exact state-of-charge reformulation for ECE 5280's single lossy battery.

Al Taha & Bitar (2024), arXiv:2403.14010v2, Theorems 1-2:
    delta_t = s_{t+1} - s_t
    p_t = delta_t / eta_in  if delta_t >= 0
          eta_out*delta_t  otherwise
    -P/eta_out <= delta_t <= eta_in*P

The transformed FEASIBLE SET is ALWAYS a convex polytope. For this project's
single buy/sell price lambda_t, the transformed OBJECTIVE is convex when
lambda_t >= 0 at every hour (see energy-arbitrage condition in Table I).
If any predicted price is negative, this module's hybrid function delegates
to the previous exact MILP; it does not pretend an LP relaxation is exact.

The daily objective has no artificial terminal-state requirement. Use only
predicted prices in live scheduling; realized prices are for offline tests.
"""
from __future__ import annotations

import numpy as np
from scipy.optimize import linprog

from battery_optimizer import (
    CAPACITY,
    EFF_IN,
    EFF_OUT,
    POWER,
    T,
    _validate_inputs,
    check_schedule,
    optimize_lossy as optimize_lossy_milp,
    stored_energy,
)


def grid_exchange_from_states(states: np.ndarray) -> np.ndarray:
    """Exactly invert lossy energy dynamics, using a length-25 SOC trajectory."""
    s = np.asarray(states, dtype=float).reshape(-1)
    if s.shape != (T + 1,) or not np.all(np.isfinite(s)):
        raise ValueError("states must contain 25 finite initial/hour-end energies")
    change = np.diff(s)
    return np.where(change >= 0.0, change / EFF_IN, EFF_OUT * change)


def optimize_lossy_convex(predicted_prices, initial_energy):
    """Exact convex LP in SOC when all 24 predicted prices are nonnegative.

    Variables are x[0:24] = hour-END stored energies and
    q[0:24] = epigraph variables for grid exchange.

    For a change delta_t, physical grid exchange is
        p(delta_t) = max(delta_t/eta_in, eta_out*delta_t),
    a convex piecewise-linear function. With lambda_t >= 0, minimizing
    sum lambda_t * p(delta_t) is convex; q >= each affine branch yields
    an LP. When lambda_t=0 q may be loose, so ALWAYS reconstruct p
    from x, not from q. This gives an exactly feasible physical schedule.

    Raises ValueError for any negative price; use optimize_lossy_hybrid
    for mixed-sign inputs.
    """
    prices, energy = _validate_inputs(predicted_prices, initial_energy)
    if np.any(prices < 0.0):
        raise ValueError(
            "Convex SOC objective requires nonnegative predicted prices; "
            "use optimize_lossy_hybrid for any negative prices."
        )

    # delta_t = x_t - x_(t-1), with x_(prior to hour 0) = initial_energy.
    diff = np.eye(T, dtype=float)
    diff[np.arange(1, T), np.arange(T - 1)] = -1.0
    offset = np.zeros(T, dtype=float)
    offset[0] = -energy
    zeros = np.zeros((T, T), dtype=float)
    minus_eye = -np.eye(T, dtype=float)

    # delta bounds are equivalent to original -POWER <= p_t <= POWER.
    upper_delta = EFF_IN * POWER
    lower_delta = -POWER / EFF_OUT

    # A_ub @ [x, q] <= b_ub
    a_ub = np.vstack((
        np.hstack((diff, zeros)),                  # delta <= upper_delta
        np.hstack((-diff, zeros)),                 # delta >= lower_delta
        np.hstack((diff / EFF_IN, minus_eye)),     # q >= delta/eta_in
        np.hstack((EFF_OUT * diff, minus_eye)),    # q >= eta_out*delta
    ))
    b_ub = np.concatenate((
        np.full(T, upper_delta) - offset,
        np.full(T, -lower_delta) + offset,
        -offset / EFF_IN,
        -EFF_OUT * offset,
    ))

    # Minimize cost = sum_t predicted_price_t * q_t.
    # The q bounds improve numerical scaling; they do not restrict any
    # physical exchange attainable from the delta bounds above.
    objective = np.r_[np.zeros(T), prices]
    bounds = [(0.0, CAPACITY)] * T + [(-POWER, POWER)] * T
    solved = linprog(objective, A_ub=a_ub, b_ub=b_ub,
                     bounds=bounds, method="highs")
    if not solved.success or solved.x is None:
        raise RuntimeError(f"SOC convex LP failed: {solved.message}")

    states = np.r_[energy, solved.x[:T]]
    schedule = grid_exchange_from_states(states)
    check_schedule(schedule, energy, lossy=True, tol=2e-6)
    # Verify that the returned schedule actually produces the optimized states.
    reconstructed_states = stored_energy(schedule, energy, lossy=True)
    if not np.allclose(reconstructed_states, states, atol=2e-6, rtol=0):
        raise RuntimeError("SOC reconstruction failed")
    return np.asarray(schedule, dtype=float)


def optimize_lossy_hybrid(predicted_prices, initial_energy, *, return_method=False):
    """Use exact SOC convex LP for all-nonnegative prices, exact MILP otherwise.

    Returns a 24-element grid exchange vector by default. Set return_method
    to True for a pair (schedule, 'soc_convex_lp' or 'exact_milp').
    """
    prices, energy = _validate_inputs(predicted_prices, initial_energy)
    if np.all(prices >= 0.0):
        p = optimize_lossy_convex(prices, energy)
        method = "soc_convex_lp"
    else:
        p = optimize_lossy_milp(prices, energy)
        method = "exact_milp"
    return (p, method) if return_method else p
