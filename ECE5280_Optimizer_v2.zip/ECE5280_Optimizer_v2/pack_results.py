"""Bundle outputs and reproducibility files after running the notebook.

Run: `python pack_results.py` from the extracted project folder.
"""
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'ECE5280_RESULTS_TO_SHARE.zip'
FILES=[
    ROOT/'ECE5280_Optimizer_v2.ipynb',
    ROOT/'optimizer.py',
    ROOT/'experiments.py',
    ROOT/'test_optimizer.py',
    ROOT/'requirements.txt',
]


def create_results_zip():
    result_dir=ROOT/'results'
    if not (result_dir/'run_manifest.json').exists():
        raise FileNotFoundError('Run notebook (or experiments.py) before zipping results')
    filepaths=FILES+[p for p in result_dir.rglob('*') if p.is_file()]
    with ZipFile(OUT,'w',compression=ZIP_DEFLATED) as archive:
        for file in filepaths:
            archive.write(file,file.relative_to(ROOT))
    print(f'Results ZIP ready: {OUT.name} ({OUT.stat().st_size:,} bytes)')
    print('Note: Save the notebook in Jupyter BEFORE creating ZIP to include its latest cell outputs.')
    return OUT


if __name__=='__main__':
    create_results_zip()
