"""Run `python -m unittest -v test_optimizer.py` from this folder."""
import unittest
import numpy as np

from optimizer import (
    T,CAPACITY,POWER,ETA_IN,ETA_OUT,check_schedule,stored_energy,
    optimize_lossless,optimize_lossy_soc_convex,optimize_lossy_milp,
    optimize_lossy_hybrid,optimize_lossy_relaxation,physical_power_from_states,
    worst_case_revenue,soc_objective_convex,
)


class OptimizerTests(unittest.TestCase):
    def setUp(self):
        self.rng=np.random.default_rng(2026)

    def test_model_constants(self):
        self.assertEqual((T,CAPACITY,POWER,ETA_IN,ETA_OUT),(24,5.,2.5,.95,.95))

    def test_idle(self):
        for initial in [0.,2.5,5.]:
            self.assertTrue(check_schedule(np.zeros(24), initial, lossy=True))

    def test_both_edges_and_signs(self):
        p=np.r_[[-2.5]*2, [2.5]*2, np.zeros(20)]
        check_schedule(p,5.,lossy=False)
        s=stored_energy(p,5.,lossy=True)
        self.assertAlmostEqual(s[1],5-2.5/.95,places=7)

    def test_lossless_mixed_prices(self):
        lam=np.r_[[-20.]*5,[30.]*10,[70.]*9]
        for init in [0.,2.,5.]:
            for radius in [0.,2.5,10.]:
                p=optimize_lossless(lam,init,price_radius=radius)
                self.assertTrue(check_schedule(p,init,lossy=False))

    def test_soc_inverse(self):
        # Direct physical reconstruction on a feasible trajectory
        p=np.r_[[-2.],np.zeros(22),[1.]]
        s=stored_energy(p,4.,lossy=True)
        np.testing.assert_allclose(physical_power_from_states(s),p,atol=1e-8,rtol=0)

    def test_soc_lp_exact_nominal_and_robust(self):
        for radius in [0.,2.5,8.]:
            for _ in range(14):
                lam=self.rng.uniform(4,110,size=24)
                init=self.rng.uniform(0,5)
                lp=optimize_lossy_soc_convex(lam,init,price_radius=radius)
                mip=optimize_lossy_milp(lam,init,price_radius=radius)
                self.assertTrue(check_schedule(lp,init,lossy=True))
                self.assertAlmostEqual(worst_case_revenue(lam,lp,radius),
                                       worst_case_revenue(lam,mip,radius),delta=1e-4)

    def test_negative_prices_with_robust_convexification(self):
        lam=np.r_[[-10.]*10,[40.]*14]
        self.assertFalse(soc_objective_convex(lam,0.))
        self.assertTrue(soc_objective_convex(lam,2.5))
        p_lp=optimize_lossy_soc_convex(lam,5.,price_radius=2.5)
        p_mip=optimize_lossy_milp(lam,5.,price_radius=2.5)
        self.assertAlmostEqual(worst_case_revenue(lam,p_lp,2.5),
                               worst_case_revenue(lam,p_mip,2.5),delta=1e-4)

    def test_hybrid_negative_fallback(self):
        lam=np.r_[[-100.]*8,[45.]*16]
        p, method=optimize_lossy_hybrid(lam,5.,return_method=True)
        self.assertEqual(method,'exact_milp_fallback')
        self.assertTrue(check_schedule(p,5.,lossy=True))

    def test_relaxation_not_always_exact(self):
        lam=np.full(24,-100.)
        r=optimize_lossy_relaxation(lam,5.)
        self.assertGreater(r.simultaneous_energy,1.0)
        self.assertFalse(r.physically_exact)
        p=optimize_lossy_hybrid(lam,5.)
        self.assertTrue(check_schedule(p,5.,lossy=True))
        self.assertLessEqual(worst_case_revenue(lam,p),-r.relaxed_worst_cost+1e-4)

    def test_terminal_value_soc_lp_milp_agreement(self):
        for value in [0.,25.,50.,85.]:
            prices=self.rng.uniform(8,125,size=24)
            energy=3.8
            soc=optimize_lossy_soc_convex(prices,energy,terminal_value=value)
            milp=optimize_lossy_milp(prices,energy,terminal_value=value)
            lhs=-worst_case_revenue(prices,soc)-value*stored_energy(soc,energy,lossy=True)[-1]
            rhs=-worst_case_revenue(prices,milp)-value*stored_energy(milp,energy,lossy=True)[-1]
            self.assertAlmostEqual(lhs,rhs,delta=2e-4)

    def test_worst_case_bound_inside_assumed_box(self):
        prices=np.linspace(-20,70,24)
        p=self.rng.uniform(-2.5,2.5,24)
        radius=2.5
        actual=prices+self.rng.uniform(-radius,radius,24)
        from optimizer import realized_revenue
        self.assertGreaterEqual(realized_revenue(actual,p)+1e-9,
                                worst_case_revenue(prices,p,radius))

    def test_final_day_no_salvage_credit(self):
        from experiments import run_chronological_backtest
        a=run_chronological_backtest(days=1,starting_training_day=300,
                kinds=('lossless',),radii=(0.,),predictors=('last_7_mean',),terminal_value=0.)
        b=run_chronological_backtest(days=1,starting_training_day=300,
                kinds=('lossless',),radii=(0.,),predictors=('last_7_mean',),terminal_value=90.)
        self.assertAlmostEqual(a[0]['realized_revenue_usd'],b[0]['realized_revenue_usd'])
        self.assertEqual(b[0]['applied_terminal_value_usd_per_mwh'],0.)

    def test_no_leakage_signature(self):
        import inspect
        self.assertNotIn('actual_prices',inspect.signature(optimize_lossy_hybrid).parameters)


if __name__ == '__main__':
    unittest.main(verbosity=2)
