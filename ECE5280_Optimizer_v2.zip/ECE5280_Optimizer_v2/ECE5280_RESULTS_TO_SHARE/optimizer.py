"""ECE 4800/5280: physically exact and relaxed battery optimizers.

No realized same-day prices enter this module. Every optimizer takes *predicted*
prices (24 hourly values), a known initial energy, and an optional box-uncertainty
radius measured in $/MWh. The base battery parameters come from the assignment.

Al Taha & Bitar (2024), arXiv:2403.14010v2, Theorems 1-2:
  delta_t = s_(t+1) - s_t
  p_t = delta_t / eta_in  (delta >= 0), else eta_out * delta_t
  -POWER / eta_out <= delta_t <= eta_in * POWER
The SOC feasibility set is convex for ALL prices; the SOC optimization objective
is convex only when the piecewise cost slopes are ordered correctly.

For independent uncertain hourly prices in [forecast-rho, forecast+rho],
worst-case daily grid cost = sum(forecast*p + rho*abs(p)). This is a modeling
assumption for experiments, NOT a statistical guarantee or a course parameter.
The robust cost in SOC coordinates has two linear branches with slopes
  a=(forecast+rho)/eta_in for delta>=0,
  b=(forecast-rho)*eta_out for delta<=0.
Its epigraph is EXACTLY convex iff a >= b for every hour.

The split-charge/discharge LP is a RELAXATION, not always feasible for the
physical one-variable lossy model. Do not submit its raw net schedule without
verifying exact physical SOC consistency. The hybrid uses exact SOC LP or MILP.
"""
from __future__ import annotations

from dataclasses import dataclass
from time import perf_counter
from typing import Any

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, linprog, milp
from scipy.sparse import lil_matrix

T = 24
CAPACITY = 5.0  # MWh
POWER = 2.5     # MWh per one-hour interval (2.5 MW)
ETA_IN = 0.95
ETA_OUT = 0.95


def validate_inputs(prices, initial_energy, price_radius=0.0, terminal_value=0.0):
    prices = np.asarray(prices, dtype=float).reshape(-1)
    if prices.shape != (T,) or not np.all(np.isfinite(prices)):
        raise ValueError('prices must be exactly 24 finite hourly $/MWh values')
    energy = float(initial_energy)
    if not np.isfinite(energy) or not (-2e-6 <= energy <= CAPACITY + 2e-6):
        raise ValueError(f'initial_energy must lie in [0, 5] MWh (received {energy:.12f})')
    # Solvers may leave tiny roundoff at the exact 0 / 5 MWh boundaries.
    energy = float(np.clip(energy, 0.0, CAPACITY))
    rho = np.broadcast_to(np.asarray(price_radius, dtype=float), (T,)).copy()
    if not np.all(np.isfinite(rho)) or np.any(rho < 0):
        raise ValueError('price_radius must be finite and nonnegative ($/MWh)')
    value = float(terminal_value)
    if not np.isfinite(value):
        raise ValueError('terminal_value must be finite ($/MWh)')
    return prices, energy, rho, value


def stored_energy(schedule, initial_energy, *, lossy):
    p = np.asarray(schedule, dtype=float).reshape(-1)
    if p.shape != (T,) or not np.all(np.isfinite(p)):
        raise ValueError('schedule must be a finite length-24 vector')
    increments = (ETA_IN*np.maximum(p, 0.) + np.minimum(p, 0.)/ETA_OUT) if lossy else p
    return np.r_[float(initial_energy), float(initial_energy) + np.cumsum(increments)]


def check_schedule(schedule, initial_energy, *, lossy, tol=1e-6):
    p = np.asarray(schedule, dtype=float).reshape(-1)
    if p.shape != (T,) or not np.all(np.isfinite(p)):
        raise ValueError('invalid 24-hour grid exchange schedule')
    if np.any(p < -POWER-tol) or np.any(p > POWER+tol):
        raise ValueError('hourly charge/discharge limit exceeded')
    s = stored_energy(p, initial_energy, lossy=lossy)
    if s.min() < -tol or s.max() > CAPACITY+tol:
        raise ValueError(f'SOC outside [0,5]: min={s.min():.9f}, max={s.max():.9f}')
    return True


def realized_revenue(actual_prices, schedule):
    lam = np.asarray(actual_prices, dtype=float).reshape(-1)
    p = np.asarray(schedule, dtype=float).reshape(-1)
    if lam.shape != (T,) or p.shape != (T,) or not np.all(np.isfinite(lam)) or not np.all(np.isfinite(p)):
        raise ValueError('actual prices and schedule must be finite 24-vectors')
    return float(-lam @ p)


def worst_case_revenue(forecast_prices, schedule, price_radius=0.0):
    p = np.asarray(schedule, dtype=float).reshape(-1)
    lam, _, rho, _ = validate_inputs(forecast_prices, 0, price_radius)
    if p.shape != (T,) or not np.all(np.isfinite(p)):
        raise ValueError('schedule must be a finite length-24 vector')
    return float(-lam @ p - rho @ np.abs(p))


def physical_power_from_states(states):
    states = np.asarray(states, dtype=float).reshape(-1)
    if states.shape != (T+1,) or not np.all(np.isfinite(states)):
        raise ValueError('states must be 25 finite SOC values')
    delta = np.diff(states)
    return np.where(delta >= 0, delta/ETA_IN, ETA_OUT*delta)


def soc_objective_convex(prices, price_radius=0.0):
    lam, _, rho, _ = validate_inputs(prices, 0, price_radius)
    charge_slope = (lam+rho)/ETA_IN
    discharge_slope = (lam-rho)*ETA_OUT
    return bool(np.all(charge_slope >= discharge_slope - 1e-10))


def _soc_diff(energy):
    # delta = D @ x + offset; x = 24 end-of-hour SOC variables.
    D = np.eye(T)
    D[np.arange(1,T), np.arange(T-1)] = -1.0
    offset = np.zeros(T)
    offset[0] = -energy
    return D, offset


def optimize_lossless(prices, initial_energy, *, price_radius=0.0, terminal_value=0.0):
    """Exact robust or nominal lossless LP; 24 MWh grid exchanges."""
    lam, energy, rho, v = validate_inputs(prices, initial_energy, price_radius, terminal_value)
    L = np.tril(np.ones((T,T)))
    if np.all(rho == 0):
        # Minimize lambda @ p - v * s_end (constant -v*initial omitted).
        ans = linprog(lam - v, A_ub=np.vstack((L, -L)),
                      b_ub=np.r_[np.full(T,CAPACITY-energy), np.full(T,energy)],
                      bounds=[(-POWER,POWER)]*T, method='highs')
    else:
        I = np.eye(T)
        A_ub = np.vstack((
            np.hstack((L, np.zeros((T,T)))),
            np.hstack((-L,np.zeros((T,T)))),
            np.hstack((np.diag(lam+rho),-I)),
            np.hstack((np.diag(lam-rho),-I)),
        ))
        b_ub = np.r_[np.full(T,CAPACITY-energy),np.full(T,energy),np.zeros(2*T)]
        ans = linprog(np.r_[np.full(T,-v),np.ones(T)], A_ub=A_ub,b_ub=b_ub,
                      bounds=[(-POWER,POWER)]*T + [(None,None)]*T,method='highs')
    if not ans.success or ans.x is None:
        raise RuntimeError('lossless LP failed: '+ans.message)
    p = np.asarray(ans.x[:T], dtype=float)
    check_schedule(p,energy,lossy=False)
    return p


def optimize_lossy_soc_convex(prices, initial_energy, *, price_radius=0.0, terminal_value=0.0):
    """Exact convex SOC LP when robust branch slopes satisfy a >= b.

    Epigraph q >= a*delta and q >= b*delta; minimize sum(q)-v*s_end.
    At optimality q=max(a*delta,b*delta), which equals the true worst-case
    cost for each physically realizable SOC change when a >= b.
    """
    lam,energy,rho,v = validate_inputs(prices,initial_energy,price_radius,terminal_value)
    a = (lam+rho)/ETA_IN
    b = (lam-rho)*ETA_OUT
    if np.any(a < b-1e-10):
        raise ValueError('SOC cost is nonconvex for this price/radius vector; use hybrid exact MILP fallback')
    D,offset = _soc_diff(energy)
    Z = np.zeros((T,T))
    minus_I = -np.eye(T)
    A_ub = np.vstack((
        np.hstack((D,Z)),
        np.hstack((-D,Z)),
        np.hstack((a[:,None]*D,minus_I)),
        np.hstack((b[:,None]*D,minus_I)),
    ))
    lb_delta = -POWER/ETA_OUT
    ub_delta = POWER*ETA_IN
    b_ub = np.r_[
        np.full(T,ub_delta)-offset,
        np.full(T,-lb_delta)+offset,
        -a*offset,
        -b*offset,
    ]
    objective = np.r_[np.r_[np.zeros(T-1), -v], np.ones(T)]
    ans = linprog(objective,A_ub=A_ub,b_ub=b_ub,
                  bounds=[(0.,CAPACITY)]*T+[(None,None)]*T,
                  method='highs')
    if not ans.success or ans.x is None:
        raise RuntimeError('convex SOC LP failed: '+ans.message)
    states = np.r_[energy,ans.x[:T]]
    p = physical_power_from_states(states)
    check_schedule(p,energy,lossy=True,tol=2e-6)
    reconstructed = stored_energy(p,energy,lossy=True)
    if not np.allclose(states,reconstructed,atol=2e-6,rtol=0.):
        raise RuntimeError('SOC inversion numerical error')
    expected = float(lam @ p+rho @ np.abs(p)-v*states[-1])
    if abs(expected-ans.fun) > 2e-4*max(1.,abs(expected)):
        raise RuntimeError('SOC epigraph does not match recovered physical cost')
    return p


def optimize_lossy_milp(prices,initial_energy, *, price_radius=0.0,terminal_value=0.0,
                         time_limit=10.0):
    """Exact charge/discharge MILP for arbitrary (including negative) prices.

    Binary mode y enforces no simultaneous charging/discharging. The robust
    objective is linear because when charging, worst price is lam+rho; when
    discharging, worst price is lam-rho.
    """
    lam,energy,rho,v = validate_inputs(prices,initial_energy,price_radius,terminal_value)
    n=3*T
    costs=np.r_[(lam+rho)-v*ETA_IN, -(lam-rho)+v/ETA_OUT, np.zeros(T)]
    A=lil_matrix((4*T,n),dtype=float)
    lb=np.full(4*T,-np.inf)
    ub=np.zeros(4*T)
    for t in range(T):
        # c_t <= POWER*y_t; d_t <= POWER*(1-y_t)
        A[t,t]=1.; A[t,2*T+t]=-POWER
        A[T+t,T+t]=1.; A[T+t,2*T+t]=POWER
        ub[T+t]=POWER
        A[2*T+t,:t+1]=ETA_IN
        A[2*T+t,T:T+t+1]=-1/ETA_OUT
        ub[2*T+t]=CAPACITY-energy
        A[3*T+t,:t+1]=ETA_IN
        A[3*T+t,T:T+t+1]=-1/ETA_OUT
        lb[3*T+t]=-energy; ub[3*T+t]=np.inf
    integrality=np.r_[np.zeros(2*T,dtype=int),np.ones(T,dtype=int)]
    ans=milp(costs,integrality=integrality,
             bounds=Bounds(np.zeros(n),np.r_[np.full(2*T,POWER),np.ones(T)]),
             constraints=LinearConstraint(A.tocsr(),lb,ub),
             options={'time_limit':float(time_limit),'mip_rel_gap':1e-9})
    if ans.status != 0 or ans.x is None:
        raise RuntimeError('exact MILP failed to certify optimality: '+ans.message)
    p=np.asarray(ans.x[:T]-ans.x[T:2*T],dtype=float)
    check_schedule(p,energy,lossy=True,tol=2e-6)
    return p


def optimize_lossy_hybrid(prices,initial_energy,*,price_radius=0.0,
                          terminal_value=0.0, return_method=False):
    """Production-safe: exact convex SOC LP when possible; exact MILP otherwise."""
    if soc_objective_convex(prices,price_radius):
        p=optimize_lossy_soc_convex(prices,initial_energy,price_radius=price_radius,
                                   terminal_value=terminal_value)
        method='exact_soc_convex_lp'
    else:
        p=optimize_lossy_milp(prices,initial_energy,price_radius=price_radius,
                              terminal_value=terminal_value)
        method='exact_milp_fallback'
    return (p,method) if return_method else p


@dataclass
class RelaxationDiagnostic:
    charge: np.ndarray
    discharge: np.ndarray
    net_exchange: np.ndarray
    model_soc: np.ndarray
    physical_soc: np.ndarray
    simultaneous_energy: float
    physically_exact: bool
    relaxed_worst_cost: float


def optimize_lossy_relaxation(prices,initial_energy, *,price_radius=0.0,terminal_value=0.0):
    """Convex OUTER RELAXATION for comparison only; may not be physical.

    c,d >= 0 allowed concurrently; p=c-d. For robust interval prices, model
    worst-case net grid cost using epigraph q >= (lam +/- rho)*(c-d).
    This relaxation has a potentially lower optimal cost than physical model.
    NEVER return the result directly to the project's evaluator without a
    physical-consistency check.
    """
    lam,energy,rho,v=validate_inputs(prices,initial_energy,price_radius,terminal_value)
    # x=[c24,d24,q24]. SOC=energy + L @ (eta_in*c - d/eta_out)
    L=np.tril(np.ones((T,T))); I=np.eye(T)
    soc=np.hstack((ETA_IN*L, -L/ETA_OUT, np.zeros((T,T))))
    eqpos=np.hstack((np.diag(lam+rho),-np.diag(lam+rho),-I))
    eqneg=np.hstack((np.diag(lam-rho),-np.diag(lam-rho),-I))
    A_ub=np.vstack((soc,-soc,eqpos,eqneg))
    b_ub=np.r_[np.full(T,CAPACITY-energy),np.full(T,energy),np.zeros(2*T)]
    costs=np.r_[np.full(T,-v*ETA_IN),np.full(T,v/ETA_OUT),np.ones(T)]
    ans=linprog(costs,A_ub=A_ub,b_ub=b_ub,
                bounds=[(0,POWER)]*(2*T)+[(None,None)]*T,method='highs')
    if not ans.success or ans.x is None:
        raise RuntimeError('convex split relaxation failed: '+ans.message)
    c,d=ans.x[:T],ans.x[T:2*T]
    p=c-d
    model_soc=np.r_[energy,energy+np.cumsum(ETA_IN*c-d/ETA_OUT)]
    physical_soc=stored_energy(p,energy,lossy=True)
    overlap=float(np.sum(np.minimum(c,d)))
    same=np.allclose(model_soc,physical_soc,atol=1e-6,rtol=0.)
    feasible=(physical_soc.min()>=-1e-6 and physical_soc.max()<=CAPACITY+1e-6 and
              np.all(np.abs(p)<=POWER+1e-6))
    return RelaxationDiagnostic(c,d,p,model_soc,physical_soc,
                                overlap,bool(same and feasible),
                                float(lam@p+rho@np.abs(p)-v*model_soc[-1]))


def solve_with_timing(kind,prices,initial_energy, *, price_radius=0.0,terminal_value=0.0):
    """Convenience for notebook timings and method reporting."""
    begin=perf_counter()
    if kind=='lossless':
        p=optimize_lossless(prices,initial_energy,price_radius=price_radius,
                            terminal_value=terminal_value)
        method='lossless_lp'; lossy=False
    elif kind=='lossy_hybrid':
        p,method=optimize_lossy_hybrid(prices,initial_energy,price_radius=price_radius,
                                       terminal_value=terminal_value,return_method=True)
        lossy=True
    elif kind=='lossy_milp':
        p=optimize_lossy_milp(prices,initial_energy,price_radius=price_radius,
                              terminal_value=terminal_value)
        method='exact_milp'; lossy=True
    else:
        raise ValueError('kind must be lossless, lossy_hybrid, or lossy_milp')
    return {'schedule':p,'method':method,'runtime_ms':1000*(perf_counter()-begin),
            'soc':stored_energy(p,initial_energy,lossy=lossy),
            'worst_case_revenue':worst_case_revenue(prices,p,price_radius)}
