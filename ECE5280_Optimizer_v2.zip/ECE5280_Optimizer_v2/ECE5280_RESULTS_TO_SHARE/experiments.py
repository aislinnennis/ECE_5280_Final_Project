"""Reproducible ECE 5280 offline trials; no future data exposed to scheduler.

The supplied released data is allowed for local historical diagnostics, but is
NOT the hidden evaluator. On day i, forecasts may use only previous-day records;
realized same-day prices are exposed exclusively to realized_revenue().
"""
from __future__ import annotations

import csv
import json
import platform
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

# Do not force the Agg backend: Jupyter needs its inline backend.
# Headless batch runs can set MPLBACKEND=Agg in the environment.
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import scipy

from optimizer import (
    T, POWER, CAPACITY, ETA_IN, ETA_OUT, check_schedule, stored_energy,
    realized_revenue, worst_case_revenue, optimize_lossy_relaxation,
    solve_with_timing,
)

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'results'
FIGURES = RESULTS / 'figures'


def read_days(path):
    """Read chronological 24-row daily records from released project CSV."""
    result=[]
    rows=[]
    with open(path, newline='', encoding='utf-8-sig') as f:
        for r in csv.DictReader(f):
            rows.append(r)
            if len(rows)==T:
                hours=[int(x['hour']) for x in rows]
                if hours!=list(range(1,T+1)):
                    raise ValueError(f'expected hours 1..24 in {path}: {hours}')
                dates={(x['month'],x['day_of_month'],x['day_of_week']) for x in rows}
                if len(dates)!=1:
                    raise ValueError('daily group has inconsistent date fields')
                result.append({
                    'label':f"{int(rows[0]['month']):02d}-{int(rows[0]['day_of_month']):02d}",
                    'weekday':int(rows[0]['day_of_week']),
                    'net_load_forecast':np.array([float(x['da_net_load_forecast_mw']) for x in rows]),
                    'realized_load':np.array([float(x['realized_net_load_mw']) for x in rows]),
                    'realized_price':np.array([float(x['da_price_usd_per_mwh']) for x in rows]),
                })
                rows=[]
    if rows:
        raise ValueError('CSV must have a multiple of 24 rows')
    return result


def read_released_dataset():
    history=read_days(ROOT/'data'/'initial_history.csv')
    training=read_days(ROOT/'data'/'training_data.csv')
    if len(history)!=7:
        raise ValueError('expected 7 initial history days')
    if len(training)<7:
        raise ValueError('training dataset needs at least 7 days')
    return history,training


def available_price_forecast(all_days,day_idx,predictor):
    """Naive forecasts. Never access all_days[day_idx]['realized_price'].

    The past-7 data is valid at the time the current-day decision is made.
    These are NOT models fitted by Vaishnavi; replace with her forecasts later.
    """
    if day_idx<7:
        raise ValueError('requires a 7-day lookback')
    prior=np.vstack([all_days[day_idx-k]['realized_price'] for k in range(1,8)])
    if predictor=='yesterday':
        return prior[0].copy()
    if predictor=='last_7_mean':
        return prior.mean(axis=0)
    raise ValueError('predictor must be yesterday or last_7_mean')


def artificial_scenarios():
    t=np.arange(T)
    return {
        'flat_positive':np.full(T,50.),
        'cheap_then_expensive':np.r_[np.full(12,15.),np.full(12,95.)],
        'expensive_then_cheap':np.r_[np.full(12,95.),np.full(12,15.)],
        'negative_window':np.r_[np.full(8,-90.),np.full(16,70.)],
        'smooth_day':30+18*np.sin(2*np.pi*(t-8)/24),
    }


def run_smoke_trials(price_radius=2.5):
    rows=[]
    for name,lam in artificial_scenarios().items():
        for energy in [0.,5.]:
            for rho in [0.,price_radius]:
                for kind in ['lossless','lossy_hybrid']:
                    out=solve_with_timing(kind,lam,energy,price_radius=rho)
                    rows.append({
                        'scenario':name,'kind':kind,'initial_energy':energy,
                        'uncertainty_usd_per_mwh':rho,'method':out['method'],
                        'predicted_revenue_usd':round(realized_revenue(lam,out['schedule']),5),
                        'worst_case_revenue_usd':round(out['worst_case_revenue'],5),
                        'ending_energy_mwh':round(float(out['soc'][-1]),5),
                        'runtime_ms':round(out['runtime_ms'],3),
                        'feasible':True,
                    })
    return rows


def run_chronological_backtest(*,days=14,starting_training_day=300,
                               radii=(0.,2.5,10.),
                               predictors=('yesterday','last_7_mean'),
                               kinds=('lossless','lossy_hybrid'),
                               terminal_value=0.0):
    if not np.isfinite(float(terminal_value)) or float(terminal_value)<0:
        raise ValueError('terminal_value must be finite and nonnegative')
    history,training=read_released_dataset()
    if not (0<=starting_training_day<len(training)):
        raise ValueError('invalid starting_training_day')
    if days<1 or starting_training_day+days>len(training):
        raise ValueError('requested days extend beyond training CSV')
    timeline=history+training
    rows=[]
    for kind in kinds:
        for predictor in predictors:
            for radius in radii:
                energy=CAPACITY  # Full at beginning of EACH backtest run.
                for j in range(days):
                    day_idx=7+starting_training_day+j
                    record=timeline[day_idx]
                    forecast=available_price_forecast(timeline,day_idx,predictor)
                    # Future stored-energy value is an exploratory continuation incentive.
                    # The *final day* has no salvage credit by assignment rule.
                    daily_value=float(terminal_value) if j < days-1 else 0.0
                    out=solve_with_timing(kind,forecast,energy,price_radius=radius,
                                          terminal_value=daily_value)
                    p=out['schedule']
                    check_schedule(p,energy,lossy=(kind!='lossless'))
                    realized=realized_revenue(record['realized_price'],p)
                    next_energy=float(out['soc'][-1])
                    rows.append({
                        'kind':kind,'predictor':predictor,'uncertainty_usd_per_mwh':radius,
                        'terminal_value_usd_per_mwh':float(terminal_value),
                        'applied_terminal_value_usd_per_mwh':daily_value,
                        'empirical_hourly_coverage_fraction':round(float(np.mean(
                            np.abs(forecast-record['realized_price']) <= radius + 1e-10)),6),
                        'day_index':j,'training_day_index':starting_training_day+j,
                        'month_day':record['label'],
                        'initial_energy_mwh':round(energy,9),
                        'ending_energy_mwh':round(next_energy,9),
                        'realized_revenue_usd':round(realized,8),
                        'predicted_revenue_usd':round(realized_revenue(forecast,p),8),
                        'worst_case_revenue_usd':round(out['worst_case_revenue'],8),
                        'method':out['method'],
                        'runtime_ms':round(out['runtime_ms'],5),
                        'max_abs_exchange_mwh':round(float(np.max(np.abs(p))),8),
                        'forecast_mae_usd_per_mwh':round(float(np.mean(np.abs(forecast-record['realized_price']))),8),
                    })
                    energy=next_energy
    return rows


def summarize_backtest(rows):
    grouped=defaultdict(list)
    for r in rows:
        grouped[(r['kind'],r['predictor'],r['uncertainty_usd_per_mwh'],
                 r.get('terminal_value_usd_per_mwh',0.0))].append(r)
    output=[]
    for (kind,predictor,radius,terminal_value),set_rows in grouped.items():
        output.append({
            'kind':kind,'predictor':predictor,
            'uncertainty_usd_per_mwh':radius,
            'terminal_value_usd_per_mwh':terminal_value,
            'days':len(set_rows),
            'empty_end_fraction':round(float(np.mean([abs(r['ending_energy_mwh'])<1e-5 for r in set_rows])),4),
            'mean_ending_energy_mwh':round(float(np.mean([r['ending_energy_mwh'] for r in set_rows])),4),
            'empirical_hourly_coverage_fraction':round(float(np.mean([r.get('empirical_hourly_coverage_fraction',0.) for r in set_rows])),4),
            'total_realized_revenue_usd':round(sum(r['realized_revenue_usd'] for r in set_rows),4),
            'total_worst_case_predicted_revenue_usd':round(sum(r['worst_case_revenue_usd'] for r in set_rows),4),
            'total_runtime_ms':round(sum(r['runtime_ms'] for r in set_rows),3),
            'avg_forecast_mae_usd_per_mwh':round(float(np.mean([r['forecast_mae_usd_per_mwh'] for r in set_rows])),4),
            'last_energy_mwh':set_rows[-1]['ending_energy_mwh'],
            'methods':dict(Counter(r['method'] for r in set_rows)),
        })
    return sorted(output,key=lambda x:(x['kind'],x['predictor'],x['uncertainty_usd_per_mwh'],x['terminal_value_usd_per_mwh']))


def save_csv(path,rows):
    if not rows:
        raise ValueError('cannot save empty rows')
    with open(path,'w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def save_figures(smoke_rows,backtest_rows):
    FIGURES.mkdir(parents=True,exist_ok=True)
    lam=artificial_scenarios()['negative_window']
    nominal=solve_with_timing('lossy_hybrid',lam,5.,price_radius=0.)
    robust=solve_with_timing('lossy_hybrid',lam,5.,price_radius=2.5)
    hour=np.arange(1,25)
    fig,ax=plt.subplots(figsize=(9,3.7))
    ax.step(hour,nominal['schedule'],where='mid',label='Nominal dispatch')
    ax.step(hour,robust['schedule'],where='mid',label='Robust dispatch (±$2.50/MWh)')
    ax.axhline(POWER,linestyle=':',alpha=.5);ax.axhline(-POWER,linestyle=':',alpha=.5)
    ax.set(xlabel='Hour (1–24)',ylabel='Grid exchange (MWh)',title='Physically feasible lossy dispatch: negative-price example')
    ax.legend();fig.tight_layout();fig.savefig(FIGURES/'negative_price_dispatch.png',dpi=160);plt.close(fig)

    fig,ax=plt.subplots(figsize=(9,3.7))
    ax.step(np.arange(25),nominal['soc'],where='post',label='Nominal SOC')
    ax.step(np.arange(25),robust['soc'],where='post',label='Robust SOC')
    ax.axhline(0,linestyle=':',alpha=.5);ax.axhline(CAPACITY,linestyle=':',alpha=.5)
    ax.set(xlabel='Completed hours',ylabel='Stored energy (MWh)',title='SOC always inside [0, 5] MWh')
    ax.legend();fig.tight_layout();fig.savefig(FIGURES/'negative_price_soc.png',dpi=160);plt.close(fig)

    relaxed=optimize_lossy_relaxation(np.full(T,-100.),5.)
    fig,ax=plt.subplots(figsize=(9,3.7))
    ax.plot(np.arange(25),relaxed.model_soc,label='LP-relaxation modeled SOC')
    ax.plot(np.arange(25),relaxed.physical_soc,label='Original physical model SOC')
    ax.set(xlabel='Completed hours',ylabel='Stored energy (MWh)',title='Why naive split-power LP relaxation can be invalid')
    ax.legend();fig.tight_layout();fig.savefig(FIGURES/'relaxation_soc_mismatch.png',dpi=160);plt.close(fig)

    if backtest_rows:
        groups=defaultdict(list)
        for r in backtest_rows:
            if r['kind']=='lossy_hybrid' and r['predictor']=='yesterday':
                groups[r['uncertainty_usd_per_mwh']].append(r)
        fig,ax=plt.subplots(figsize=(9,3.8))
        for radius,items in sorted(groups.items()):
            items=sorted(items,key=lambda x:x['day_index'])
            ax.plot(range(1,len(items)+1),np.cumsum([r['realized_revenue_usd'] for r in items]),
                    label=f'Uncertainty ±${radius:g}/MWh')
        ax.set(xlabel='Backtest day',ylabel='Cumulative realized revenue ($)',
               title='Historical-training backtest (not hidden validation/test)')
        ax.legend();fig.tight_layout();fig.savefig(FIGURES/'cumulative_revenue.png',dpi=160);plt.close(fig)


def export_all(*,days=14,starting_training_day=300,
               radii=(0.,2.5,10.),predictors=('yesterday','last_7_mean')):
    RESULTS.mkdir(parents=True,exist_ok=True)
    smoke=run_smoke_trials(price_radius=2.5)
    backtest=run_chronological_backtest(days=days,starting_training_day=starting_training_day,
                                       radii=radii,predictors=predictors)
    summary=summarize_backtest(backtest)
    save_csv(RESULTS/'smoke_trials.csv',smoke)
    save_csv(RESULTS/'backtest_daily.csv',backtest)
    serializable_summary=[]
    for r in summary:
        serializable_summary.append({**r,'methods':json.dumps(r['methods'],sort_keys=True)})
    save_csv(RESULTS/'backtest_summary.csv',serializable_summary)
    save_figures(smoke,backtest)
    manifest={
        'created_utc':datetime.now(timezone.utc).isoformat(),
        'purpose':'Offline experiments using released training data, not hidden evaluator scores',
        'parameters':{'days':days,'starting_training_day':starting_training_day,
                      'radii_usd_per_mwh':list(radii),'predictors':list(predictors),
                      'initial_soc_mwh':CAPACITY,'power_limit_mwh':POWER,
                      'eta_in':ETA_IN,'eta_out':ETA_OUT},
        'versions':{'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,
                    'matplotlib':matplotlib.__version__,'platform':platform.platform()},
        'summary':summary,
    }
    (RESULTS/'run_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    return {'smoke':smoke,'daily':backtest,'summary':summary,'manifest':manifest}


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(description='Run ECE5280 optimizer trial suite')
    p.add_argument('--days',type=int,default=14)
    p.add_argument('--start',type=int,default=300)
    args=p.parse_args()
    output=export_all(days=args.days,starting_training_day=args.start)
    for item in output['summary']:
        print(item)
    print('\nSaved trial results to',RESULTS)


def run_terminal_value_sweep(*,days=14,starting_training_day=300,
                             terminal_values=(0.0,20.0,40.0,60.0,80.0),
                             radii=(0.0,2.5),
                             predictors=('yesterday','last_7_mean'),
                             kinds=('lossless','lossy_hybrid')):
    """Explore carrying energy across days; no credit for ending SOC on final day.

    The continuation value is an EXPERIMENTAL heuristic, not a true future-price
    forecast or a guaranteed value function. Scores are on released training data.
    """
    rows=[]
    for v in terminal_values:
        rows.extend(run_chronological_backtest(
            days=days,starting_training_day=starting_training_day,radii=radii,
            predictors=predictors,kinds=kinds,terminal_value=float(v)))
    summary=summarize_backtest(rows)
    RESULTS.mkdir(parents=True,exist_ok=True)
    save_csv(RESULTS/'terminal_value_daily.csv',rows)
    serializable=[{**r,'methods':json.dumps(r['methods'],sort_keys=True)} for r in summary]
    save_csv(RESULTS/'terminal_value_summary.csv',serializable)
    FIGURES.mkdir(parents=True,exist_ok=True)
    for kind in kinds:
        fig,ax=plt.subplots(figsize=(9,3.8))
        for pred in predictors:
            for radius in radii:
                series=sorted(
                    (r for r in summary if r['kind']==kind and r['predictor']==pred
                     and r['uncertainty_usd_per_mwh']==radius),
                    key=lambda r:r['terminal_value_usd_per_mwh'])
                ax.plot([r['terminal_value_usd_per_mwh'] for r in series],
                        [r['total_realized_revenue_usd'] for r in series],
                        marker='o',label=f'{pred}, ±${radius:g}')
        ax.set(xlabel='Continuation value ($/MWh) on nonfinal days',
               ylabel='14-day realized revenue ($)' if days==14 else 'Realized revenue ($)',
               title=f'{kind}: effect of valuing carried energy')
        ax.legend(fontsize=8);fig.tight_layout()
        fig.savefig(FIGURES/f'terminal_value_{kind}.png',dpi=160)
        plt.close(fig)
    return {'daily':rows,'summary':summary}
